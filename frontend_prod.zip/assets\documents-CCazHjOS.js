import{n as e}from"./mappers-BzNLb_vj.js";var t={primary:`#14b8a6`,accent:`#0d9488`,dark:`#0f766e`,ink:`#111113`,muted:`#71717a`,canvas:`#f7f7f8`,border:`#e4e4e7`};function n({title:e,restaurantName:n,children:r,note:i,qrDataUrl:a,qrCaption:o}){return`<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>${e}</title>
  <style>
    *{box-sizing:border-box}
    body{font-family:'Inter',ui-sans-serif,system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;color:${t.ink};margin:0;background:#ffffff;font-size:13px;-webkit-print-color-adjust:exact;print-color-adjust:exact}
    .head{display:flex;justify-content:space-between;align-items:flex-start;padding:26px 36px;background:linear-gradient(180deg,#ffffff,${t.canvas});border-bottom:3px solid ${t.primary}}
    .brand{display:flex;align-items:center;gap:12px}
    .mark{width:40px;height:40px;border-radius:12px;background:linear-gradient(135deg,${t.primary},${t.accent});color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:20px;box-shadow:0 2px 8px rgba(20,184,166,.35)}
    .brand-name{font-size:18px;font-weight:800;letter-spacing:-.02em}
    .brand-sub{font-size:11px;color:${t.muted}}
    .doc-title{font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:${t.dark}}
    .doc-meta{font-size:11px;color:${t.muted};margin-top:4px}
    .body{padding:26px 36px}
    .card{border:1px solid ${t.border};border-radius:14px;padding:16px 18px;background:#fff}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
    .label{font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:${t.muted};margin-bottom:4px}
    table{width:100%;border-collapse:collapse;margin-top:14px}
    th,td{text-align:left;padding:10px 10px;border-bottom:1px solid ${t.border}}
    th{font-size:10px;text-transform:uppercase;letter-spacing:.05em;color:${t.muted};background:${t.canvas}}
    .right{text-align:right}
    .badge{display:inline-block;padding:3px 12px;border-radius:999px;background:rgba(20,184,166,.12);color:${t.accent};font-size:11px;font-weight:700}
    .total-line{font-size:15px;font-weight:800;margin-top:14px;text-align:right}
    .muted{color:${t.muted}}
    .center{text-align:center}
    .qr-img{width:240px;height:240px;border:1px solid ${t.border};border-radius:16px;padding:10px;background:#fff}
    .foot{margin-top:36px;padding:14px 36px;border-top:1px solid ${t.border};font-size:11px;color:${t.muted};display:flex;justify-content:space-between}
    @media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
  </style></head><body>
  <div class="head">
    <div class="brand">
      <div class="mark">R</div>
      <div>
        <div class="brand-name">RestoHub</div>
        <div class="brand-sub">${n}</div>
      </div>
    </div>
    <div style="text-align:right">
      <div class="doc-title">${e}</div>
      <div class="doc-meta">Généré le ${new Date().toLocaleDateString(`fr-FR`)}</div>
    </div>
  </div>
  <div class="body">${r}</div>
  <div class="foot">
    <span>${n} · RestoHub</span>
    ${a?`<span style="display:flex;align-items:center;gap:10px">
             ${o?`<span style="text-align:right">${o}</span>`:``}
             <img src="${a}" alt="QR Code" style="width:84px;height:84px;border:1px solid ${t.border};border-radius:8px;padding:4px;background:#fff" />
           </span>`:i?`<span>${i}</span>`:``}
  </div>
  <script>window.onload=function(){window.focus();window.print()}<\/script>
  </body></html>`}function r(e,t){let n=window.open(``,`_blank`);return n?(n.document.write(e),n.document.close(),null):t}function i(t){return e(t)}function a({restaurantName:e,inv:t,planName:a,qrDataUrl:o,qrCaption:s}){let c=t.number||`SUB-${String(t.id).padStart(4,`0`)}`,l={active:`Actif`,trialing:`Essai`,past_due:`En retard`,cancelled:`Annulé`,expired:`Expiré`}[t.status]||t.status,u=t.billing_cycle===`yearly`?`Annuel`:`Mensuel`,d=t.starts_at&&t.ends_at?`${new Date(t.starts_at).toLocaleDateString(`fr-FR`)} → ${new Date(t.ends_at).toLocaleDateString(`fr-FR`)}`:u;return r(n({title:`Facture d'abonnement`,restaurantName:e,note:`RestoHub — Plateforme SaaS de gestion de restaurants`,qrDataUrl:o,qrCaption:s||`Espace facturation`,children:`
        <div class="grid">
          <div class="card">
            <div class="label">Numéro</div>
            <div style="font-weight:700">${c}</div>
            <div class="label" style="margin-top:10px">Plan</div>
            <div>${a}</div>
          </div>
          <div class="card">
            <div class="label">Statut</div>
            <span class="badge">${l}</span>
            <div class="label" style="margin-top:10px">Cycle</div>
            <div>${u}</div>
          </div>
        </div>
        <table>
          <thead><tr><th>Désignation</th><th class="right">Période</th><th class="right">Montant</th></tr></thead>
          <tbody>
            <tr><td>Abonnement ${a}</td><td class="right">${d}</td><td class="right" style="font-weight:700">${i(t.amount)}</td></tr>
          </tbody>
        </table>
        <p class="total-line">Total : ${i(t.amount)}</p>
      `}),`Autorisez les pop-ups pour télécharger la facture`)}function o({restaurantName:e,order:t,qrDataUrl:a,qrCaption:o}){let s=t.number||t.id,c=t.items||[],l=t.subtotal==null?t.total-(t.delivery_fee||0):t.subtotal,u=c.map(e=>`
        <tr>
          <td><span style="font-weight:700">${e.qty}×</span> ${e.name||``}</td>
          <td class="right">${i((e.price||0)*e.qty)}</td>
        </tr>`).join(``);return r(n({title:`Facture de commande`,restaurantName:e,note:t.status||``,qrDataUrl:a,qrCaption:o||`Suivez votre<br/>commande`,children:`
        <div class="grid">
          <div class="card">
            <div class="label">Commande</div>
            <div style="font-weight:700">#${s}</div>
            <div class="label" style="margin-top:10px">Date</div>
            <div>${t.date||`—`}</div>
          </div>
          <div class="card">
            <div class="label">Client</div>
            <div style="font-weight:700">${t.customer?.name||`—`}</div>
            <div class="muted">${t.customer?.phone||``}</div>
            <div class="muted">${t.address&&t.address!==`—`?t.address:``}</div>
          </div>
        </div>
        <table>
          <thead><tr><th>Produit</th><th class="right">Montant</th></tr></thead>
          <tbody>${u||`<tr><td colspan="2" class="muted">Aucun article</td></tr>`}</tbody>
        </table>
        <div style="margin-top:10px;text-align:right" class="muted">
          <div>Sous-total : ${i(l)}</div>
          ${t.mode===`Livraison`?`<div>Frais de livraison : ${i(t.delivery_fee||0)}</div>`:``}
          ${t.discount>0?`<div>Réduction : -${i(t.discount)}</div>`:``}
        </div>
        <p class="total-line">Total : ${i(t.total)}</p>
        <div style="margin-top:10px" class="muted">
          Mode : ${t.mode||`—`} · Paiement : ${t.payment||`—`}
        </div>
      `}),`Autorisez les pop-ups pour imprimer le reçu`)}function s({restaurantName:e,url:t,qrDataUrl:i}){return r(n({title:`QR Code du menu`,restaurantName:e,note:`Scannez pour voir le menu`,children:`
        <div class="center" style="padding:8px 0">
          <div class="card" style="display:inline-block;text-align:center">
            ${i?`<img src="${i}" alt="QR Code" class="qr-img" />`:``}
            <p style="font-weight:700;font-size:16px;margin:12px 0 4px">${e}</p>
            <p class="muted" style="font-size:12px;margin:0">${t}</p>
          </div>
        </div>
      `}),`Autorisez les pop-ups pour télécharger le QR Code`)}export{s as n,a as r,o as t};